//
//  Models.swift
//  Doe
//
//  Доменные модели. Поля и их представление 1:1 со схемой десктопа.
//

import Foundation

/// Режим колонки. rawValue хранится в БД ровно как в десктопе (имя enum).
enum ColumnMode: String, CaseIterable, Identifiable {
    case `default`  = "DEFAULT"
    case trackTime  = "TRACK_TIME"
    case completion = "COMPLETION"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .default:    return "Обычная"
        case .trackTime:  return "Учёт времени"
        case .completion: return "Завершение"
        }
    }

    /// Безопасный разбор из БД (неизвестное -> .default).
    static func parse(_ raw: String?) -> ColumnMode {
        guard let raw, let m = ColumnMode(rawValue: raw) else { return .default }
        return m
    }
}

/// Счётчики подзадач карточки для превью на доске (кэшируются в BoardViewModel).
struct SubtaskStat: Equatable {
    var count: Int
    var done: Int
}

struct Workspace: Identifiable, Equatable, Hashable {
    var id: Int64
    var name: String
    var position: Double
    var createdAt: Date?
}

struct Column: Identifiable, Equatable, Hashable {
    var id: Int64
    var title: String
    var mode: ColumnMode
    var position: Double
    var collapsed: Bool
    var workspaceId: Int64
    var width: Double?
}

struct Card: Identifiable, Equatable, Hashable {
    var id: Int64
    var title: String
    var description: String?
    var attachmentsOrder: [String]
    var columnId: Int64
    var position: Double
    var createdAt: Date?
    var updatedAt: Date?
    var completedAt: Date?
    var dueDate: Date?
    var priority: Double?
    var isVisibleOnBoard: Bool
    var foldedHeadings: [String]
    /// ID родительских карточек (граф многие-ко-многим, All-to-All).
    var parentIds: [Int64]

    /// Первая строка описания/заголовок для превью на доске.
    var displayTitle: String {
        title.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
