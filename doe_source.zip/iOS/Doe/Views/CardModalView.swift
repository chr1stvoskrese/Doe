//
//  CardModalView.swift
//  Doe
//
//  Модалка карточки — как на десктопе, но без блоков «запоминание» и
//  «инструменты». Содержит: заголовок, Markdown-описание (редактор + живой
//  просмотр со ссылками), граф подзадач All-to-All (родители и дети с
//  переходами), напоминание, закрепление подзадачи на доске.
//

import SwiftUI

struct CardModalView: View {
    @ObservedObject var vm: BoardViewModel
    let taskId: Int64
    @Environment(\.dismiss) private var dismiss

    @State private var task: Card?
    @State private var title = ""
    @State private var descriptionText = ""
    @State private var mode: DescMode = .edit
    @State private var subtasks: [Card] = []
    @State private var parents: [Card] = []
    @State private var reminderOn = false
    @State private var reminderDate = Date().addingTimeInterval(3600)
    @State private var showLinkChild = false
    @State private var showLinkParent = false
    @State private var addSubText = ""

    private enum DescMode: String, CaseIterable { case edit = "Редактор", preview = "Просмотр" }

    var body: some View {
        NavigationStack {
            Form {
                titleSection
                descriptionSection
                subtasksSection
                parentsSection
                reminderSection
            }
            .navigationTitle("Карточка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Готово") { persist(); dismiss() }.fontWeight(.semibold)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        if task?.parentIds.isEmpty == false {
                            Toggle("Показывать на доске", isOn: Binding(
                                get: { task?.isVisibleOnBoard ?? false },
                                set: { setVisible($0) }))
                        }
                        Button(role: .destructive) {
                            vm.deleteTask(taskId); dismiss()
                        } label: { Label("Удалить карточку", systemImage: "trash") }
                    } label: { Image(systemName: "ellipsis.circle") }
                }
            }
            .onAppear(perform: reload)
            .onDisappear(perform: persist)
            .sheet(isPresented: $showLinkChild) {
                RelationPickerView(vm: vm, taskId: taskId, mode: .child) { reload() }
            }
            .sheet(isPresented: $showLinkParent) {
                RelationPickerView(vm: vm, taskId: taskId, mode: .parent) { reload() }
            }
        }
    }

    // MARK: - Секции

    private var titleSection: some View {
        Section("Заголовок") {
            TextField("Название карточки", text: $title, axis: .vertical)
                .font(.headline)
                .onSubmit(persist)
        }
    }

    private var descriptionSection: some View {
        Section {
            Picker("Режим", selection: $mode) {
                ForEach(DescMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)

            if mode == .edit {
                TextEditor(text: $descriptionText)
                    .frame(minHeight: 180)
                    .font(.system(.body, design: .default))
            } else {
                if descriptionText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    Text("Нет описания").foregroundStyle(Theme.textSecondary)
                } else {
                    MarkdownView(text: descriptionText, attachmentsDir: vm.attachmentsDir)
                        .padding(.vertical, 4)
                }
            }
        } header: { Text("Описание (Markdown)") }
    }

    private var subtasksSection: some View {
        Section {
            ForEach(subtasks) { sub in
                NavigationLink {
                    CardModalView(vm: vm, taskId: sub.id)
                } label: {
                    HStack {
                        Image(systemName: sub.completedAt != nil ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(sub.completedAt != nil ? Theme.successDone : Theme.textSecondary)
                        Text(sub.displayTitle).lineLimit(2)
                    }
                }
                .swipeActions {
                    Button(role: .destructive) {
                        vm.unlinkSubtask(parentId: taskId, childId: sub.id); reload()
                    } label: { Label("Отвязать", systemImage: "link.badge.minus") }
                }
            }
            HStack {
                TextField("Новая подзадача…", text: $addSubText)
                    .onSubmit(addSubtask)
                Button(action: addSubtask) { Image(systemName: "plus.circle.fill") }
                    .disabled(addSubText.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            Button {
                showLinkChild = true
            } label: { Label("Связать существующую", systemImage: "link") }
        } header: {
            Text("Подзадачи (\(subtasks.count))")
        } footer: {
            Text("Граф многие-ко-многим: карточка может иметь несколько родителей и детей.")
        }
    }

    @ViewBuilder
    private var parentsSection: some View {
        if !parents.isEmpty {
            Section("Родительские карточки") {
                ForEach(parents) { parent in
                    NavigationLink {
                        CardModalView(vm: vm, taskId: parent.id)
                    } label: {
                        Label(parent.displayTitle, systemImage: "arrow.up.left")
                    }
                    .swipeActions {
                        Button(role: .destructive) {
                            vm.unlinkSubtask(parentId: parent.id, childId: taskId); reload()
                        } label: { Label("Отвязать", systemImage: "link.badge.minus") }
                    }
                }
            }
        }
        Section {
            Button { showLinkParent = true } label: {
                Label("Добавить родителя", systemImage: "arrow.up.left.square")
            }
        }
    }

    private var reminderSection: some View {
        Section("Напоминание") {
            Toggle("Напомнить", isOn: $reminderOn)
                .onChange(of: reminderOn) { _, on in
                    Task { await applyReminder(on: on) }
                }
            if reminderOn {
                DatePicker("Когда", selection: $reminderDate,
                           in: Date()..., displayedComponents: [.date, .hourAndMinute])
                    .onChange(of: reminderDate) { _, _ in
                        Task { await applyReminder(on: true) }
                    }
            }
        }
    }

    // MARK: - Действия

    private func reload() {
        guard let t = vm.task(taskId) else { dismiss(); return }
        task = t
        title = t.title
        descriptionText = t.description ?? ""
        subtasks = vm.subtasks(of: taskId)
        parents = t.parentIds.compactMap { vm.task($0) }
        if let r = vm.reminderDate(for: taskId) {
            reminderOn = true; reminderDate = r
        } else {
            reminderOn = false
        }
    }

    private func persist() {
        guard let t = task else { return }
        let newTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let titleChanged = !newTitle.isEmpty && newTitle != t.title
        let descChanged = descriptionText != (t.description ?? "")
        if titleChanged || descChanged {
            vm.updateTask(taskId,
                          title: titleChanged ? newTitle : nil,
                          description: descChanged ? .some(descriptionText) : nil)
        }
    }

    private func addSubtask() {
        guard let t = task else { return }
        vm.addSubtask(parentId: taskId, title: addSubText, columnId: t.columnId)
        addSubText = ""
        reload()
    }

    private func setVisible(_ visible: Bool) {
        vm.updateTask(taskId, isVisibleOnBoard: visible)
        reload()
    }

    private func applyReminder(on: Bool) async {
        await vm.setReminder(taskId: taskId,
                             title: title.isEmpty ? "Напоминание" : title,
                             date: on ? reminderDate : nil)
    }
}
