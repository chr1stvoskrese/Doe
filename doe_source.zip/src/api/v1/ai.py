import asyncio
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import List, Optional

from src.db.database import get_session
from src.db.models import TaskModel
from src.core.config import get_active_vault
from src.services.ai_service import (
    is_apple_silicon, chat_with_ai, 
    extract_memory, calculate_priorities, AVAILABLE_MODELS, MODELS_DIR
)

router = APIRouter(prefix="/ai", tags=["ai"])

@router.get("/status")
async def get_ai_status():
    """Проверка оборудования и наличия скачанных моделей."""
    if not is_apple_silicon():
        return {"supported": False, "reason": "Requires Apple Silicon (M1+)"}
    
    downloaded = []
    for name, info in AVAILABLE_MODELS.items():
        if (MODELS_DIR / info["file"]).exists():
            downloaded.append(name)
            
        return {
            "supported": True,
            "available_models": list(AVAILABLE_MODELS.keys()),
            "downloaded_models": downloaded
        }

class DownloadReq(BaseModel):
    model_name: str

@router.post("/download")
async def download_ai_model(req: DownloadReq):
    from src.services.ai_service import download_model_with_progress
    import threading
    
    # Запускаем в фоновом Python-потоке. 
    # Он работает тихо, в рамках нашего процесса, не открывая иконки в Dock.
    threading.Thread(target=download_model_with_progress, args=(req.model_name,), daemon=True).start()
    return {"success": True, "status": "started"}

@router.get("/download-progress")
async def get_ai_download_progress(model_name: str):
    from src.services.ai_service import get_download_progress
    return get_download_progress(model_name)

@router.post("/cancel")
async def cancel_ai_download(req: DownloadReq):
    from src.services.ai_service import cancel_download
    cancel_download(req.model_name)
    return {"success": True}

@router.delete("/delete")
async def delete_ai_model(req: DownloadReq):
    from src.services.ai_service import delete_model
    success = delete_model(req.model_name)
    if not success:
        raise HTTPException(status_code=500, detail="Не удалось удалить файл модели")
    return {"success": True}

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatReq(BaseModel):
    model_name: str
    messages: List[ChatMessage]

@router.post("/chat")
async def ai_chat(req: ChatReq):
    model_info = AVAILABLE_MODELS.get(req.model_name)
    model_path = str(MODELS_DIR / model_info["file"])
    
    msgs = [{"role": m.role, "content": m.content} for m in req.messages]
    vault = get_active_vault()
    
    try:
        reply = await asyncio.to_thread(chat_with_ai, model_path, msgs, vault)
        return {"reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class PrioritizeReq(BaseModel):
    model_name: str
    daily_context: str
    chat_history: str # Для обновления памяти в фоне
    only_visible: bool

@router.post("/prioritize")
async def auto_prioritize(req: PrioritizeReq, background_tasks: BackgroundTasks, db: AsyncSession = Depends(get_session)):
    model_info = AVAILABLE_MODELS.get(req.model_name)
    model_path = str(MODELS_DIR / model_info["file"])
    vault = get_active_vault()
    
    # Запускаем обновление памяти в фоне
    background_tasks.add_task(extract_memory, model_path, req.chat_history, vault)
    
    # Собираем задачи
    stmt = select(TaskModel).where(TaskModel.completed_at.is_(None))
    if req.only_visible:
        stmt = stmt.where(TaskModel.is_visible_on_board == True)
        
    res = await db.execute(stmt)
    tasks = res.scalars().all()
    
    if not tasks:
        return {"success": True, "updated": 0}
        
    # Бьем задачи на чанки по 10 штук, чтобы не перегружать контекст LLM
    task_dicts = [{"id": t.id, "title": t.title, "description": t.description} for t in tasks]
    chunk_size = 10
    chunks = [task_dicts[i:i + chunk_size] for i in range(0, len(task_dicts), chunk_size)]
    
    updated_count = 0
    for chunk in chunks:
        try:
            ai_res = await asyncio.to_thread(calculate_priorities, model_path, req.daily_context, chunk)
            
            for ai_task in ai_res.get("tasks", []):
                t_id = ai_task.get("task_id")
                db_task = next((t for t in tasks if t.id == t_id), None)
                if db_task:
                    # Расчет итогового процента (по формуле Doe из JS)
                    c = ai_task.get("c", 5) / 10.0
                    d = ai_task.get("d", 5) / 10.0
                    a = ai_task.get("a", 5) / 10.0
                    b = ai_task.get("b", 5) / 10.0
                    e = ai_task.get("e", 5) / 10.0
                    f = ai_task.get("f", 0)
                    p = ai_task.get("p", 0) / 10.0
                    s = ai_task.get("s", 0) / 10.0
                    h = ai_task.get("h", 0) / 10.0

                    d_eff = d * 0.85
                    c_eff = pow(c, 0.85)
                    value = (c_eff * d_eff) * (1 + 0.35 * f) + 0.15 * p * d_eff
                    relief = (a * (0.10 + c_eff * (0.45 * d_eff + 0.50))) + 0.40 * s
                    friction = b * (0.62 + 0.42 * e)
                    base_score = 100 * (value + relief) / (1 + friction)
                    score = base_score * (1 - 0.75 * h)
                    
                    db_task.priority = min(100.0, max(0.0, score))
                    db_task.priority_data = {
                        "c": c*10, "d": d*10, "a": a*10, "b": b*10, "e": e*10,
                        "f": f, "p": p*10, "s": s*10, "h": h*10, "manual": False
                    }
                    updated_count += 1
        except Exception as ex:
            print(f"[AI] Chunk failed: {ex}")
            
    await db.commit()
    return {"success": True, "updated": updated_count}
