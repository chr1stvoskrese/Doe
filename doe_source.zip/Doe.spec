# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['wrapper.py'],
    pathex=[],
    binaries=[],
    datas=[('favicon.ico', '.'), ('doe.png', '.'), ('ai-logo.png', '.'), ('doe_source.zip', '.'), ('frontend', 'frontend'), ('src', 'src'), ('alembic.ini', '.'), ('alembic', 'alembic'), ('THIRD_PARTY_LICENSES.md', '.'), ('feature_flags.json', '.')],
    hiddenimports=['src.api.v1.columns', 'src.api.v1.tasks', 'src.api.v1.system', 'src.api.v1.workspaces', 'uvicorn.logging', 'uvicorn.loops', 'uvicorn.loops.auto', 'uvicorn.protocols', 'uvicorn.protocols.http', 'uvicorn.protocols.http.auto', 'uvicorn.protocols.websockets', 'uvicorn.protocols.websockets.auto', 'uvicorn.lifespan', 'uvicorn.lifespan.on', 'uvicorn.lifespan.off', 'aiosqlite', 'watchdog', 'websockets', 'webview.platforms.cocoa', 'jinja2'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Doe',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=True,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['doe.icns'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Doe',
)
app = BUNDLE(
    coll,
    name='Doe.app',
    icon='doe.icns',
    bundle_identifier='com.aesthetic.doe',
)
